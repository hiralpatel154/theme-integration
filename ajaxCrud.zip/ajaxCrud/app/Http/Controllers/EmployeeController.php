<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;
use DataTables;
use File;

class EmployeeController extends Controller
{
    public function index(Request $request)
    {
       $employee = Employee::get();
       if ($request->ajax()) 
       {
            return DataTables::of($employee)
                ->addIndexColumn()
                ->addColumn('action', function($row){
                    $actionBtn = '<button class="btn btn-primary edit" data-id="'.$row->id.'">Edit</button> <button class="btn btn-danger delete" data-id="'.$row->id.'">Delete</button>';
                    return $actionBtn;
                })
                ->addColumn('image', function($row){
                    return  '<img src="'.asset('uploads/employees/'.$row->image).'" width="50"/>';
                })
                ->rawColumns(['action','image'])
                ->make(true);
        }

       return view('employee.employee');
    }

    public function store(Request $request)
    {
        $employee = new Employee;

        if($request->hasfile('image'))
        {
            $file = $request->file('image');
            $extension = $file->getClientOriginalName();
            $filename = time().'_'.$extension;
            $file->move('uploads/employees/', $filename);

            $employee->image = $filename;
        }
        
        $employee->name = $request->name;
        $employee->save();

        return response()->json(['status' => 1, 'data' => $employee]);
    }

    public function edit(Request $request)
    {
        $employee = Employee::find($request->id);
        
        return $employee;
    }

    public function update(Request $request)
    {
        $employee = Employee::where('id',$request->id)->first();

        $image_path = "uploads/employees/".$employee->image;

        if(File::exists($image_path)) 
        {
            File::delete($image_path);
        }

        if($request->hasfile('image'))
        {
            $file = $request->file('image');
            $extension = $file->getClientOriginalName();
            $filename = time().'_'.$extension;
            $file->move('uploads/employees/', $filename);

            $employee->image = $filename;
        }
        
        $employee->name = $request->name;
        $employee->save();

        return response()->json(['status' => 1, 'data' => $employee]);
    }

    public function delete(Request $request)
    {
        $employee = Employee::find($request->id);

        $image_path = "uploads/employees/".$employee->image;

        if(File::exists($image_path)) 
        {
            File::delete($image_path);
        }

        $employee->delete();

    }
}
