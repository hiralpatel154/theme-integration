$.ajaxSetup({
    headers: {
        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
    },
});
$(document).ready(function () {
    $(".data-table").DataTable({
        destroy:true,
        processing: true,
        serverSide: true,
        ajax: "{{route('index')}}",
        columns: [
            { data: "id", name: "id" },
            { data: "name", name: "name" },
            { data: "image", name: "image" },
            {data: "action",name: "action",orderable: false,searchable: false},
        ],
    });
    $("#add_employee_form").submit(function (e) {
        e.preventDefault();
        
        var formData = new FormData(this);
        $.ajax({
            type: "post",
            url: "employee",
            data: formData,
            cache: false,
            processData: false,
            contentType: false,
            success: function (response) {
                alert("insert");
            },
        });
    });
});


